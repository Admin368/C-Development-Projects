

//tab character ; '\t'
#include<stdio.h>
#include<string.h>
int main()
{

   int stringLen;
   char mystring2[25];
   char myString[20] = "hello world";
   printf("my string is %s\n",myString);

   stringLen = strlen(myString);
   printf("my string length is: %d",stringLen);

   strcpy(mystring2, "hello world 2");
   printf("my string 2 is %s\n",mystring2);


   /*
   char tab = '\t';
   printf("tab is %d, \n", tab);
   */

   //'32' = 48 + 32
  // printf("32 is %d\n",'32');
 // char ch;
 // ch = getchar();
  //putchar(ch);
  /*
  while((ch=getchar())!='1')
  {
    putchar(ch);
  }
  */
   return 0;
}

