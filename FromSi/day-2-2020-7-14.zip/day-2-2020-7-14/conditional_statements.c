
#include <stdio.h>
int main()
{
   int num1, num2,sum;
   printf("please enter number 1: ");
    scanf("%d",&num1);
     printf("please enter number 2: ");
    scanf("%d",&num2);

    sum = num1 + num2;
    if(sum<10)
    {
        printf("entered values: num1: %d, num2�� %d\n the sum is less than 10"
               , num1,num2);
    }
    else if(sum>10)
    {
        printf("entered values: num1: %d, num2�� %d\n the sum is greater than 10"
               , num1,num2);
    }
    else{
        printf("please enter number 1: ");
        scanf("%d",&num1);
        printf("please enter number 2: ");
        scanf("%d",&num2);
        sum = num1 + num2;
        while(sum==10)
        {
             printf("entered values: num1: %d, num2�� %d\n enter values whose sum is not 10"
               , num1,num2);
                printf("please enter number 1: ");
            scanf("%d",&num1);
            printf("please enter number 2: ");
            scanf("%d",&num2);
            sum = num1 + num2;
        }
    }


    return 0;
}
