
#include <stdio.h>

int fibonacci(int prev1, int prev2);

int main()
{
    int first = 0, second = 1;
    printf("\n%d,%d,",first,second);
    fibonacci(first,second);
    return 0;
}

int fibonacci(int prev1, int prev2)
{
    // static int count = 0;
     //count = count + 1;
     int sum = prev1 + prev2;
     if(sum>1000) // less than 1000
     {
        return;
     }
     printf("%d,",sum);

    // if(count==20)
    // {
    //     return 0;
    // }

     fibonacci(prev2,sum);
}
