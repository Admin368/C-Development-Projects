
#include<stdio.h>
int main()
{
    float fah;
    int i,cent;
    printf("-----Conversion Table------\n");
    printf("Temp(degrees)       Temp(Fah)\n");
    for (i=0; i<=500; i=i+20)
    {
        cent = i;
        fah = cent*(9.0/5.0) + 32;
        printf("%10d %15.2f\n",cent,fah);
    }
    return 0;
}
