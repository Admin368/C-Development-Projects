#include<stdio.h>


int main()
{
    char myStorage[200];
    gets(myStorage);

    printf("input string is %s",myStorage);
    return 0;
}
