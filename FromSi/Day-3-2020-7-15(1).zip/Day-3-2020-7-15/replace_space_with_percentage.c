#include <stdio.h>
#include <string.h>
int main()
{
    int i;
    char ch;
    char myString[100];
    gets(myString);

    for(i = 0; i<strlen(myString); i++)
    {
        ch = myString[i];
        if(ch == ' ')
        {
            myString[i]='%%';
        }
    }
    printf("new string is: \n %s",myString);
    return 0;
}
