
#include<stdio.h>
#include<string.h>
int main()
{
    int i;
    int spaces=0, tabs=0;
    char ch;
    char myString[100];
    gets(myString);

    for(i = 0; i<strlen(myString); i++)
    {
        ch = myString[i];
        if(ch == ' ')
        {
            spaces++;// spaces = spaces + 1;

        }else if(ch ='\t')
        {
            tabs++;
        }
    }
    printf("there are %d spaces in the string\n", spaces);
    printf("there are %d tabs in the string\n", tabs);



    return 0;
}
