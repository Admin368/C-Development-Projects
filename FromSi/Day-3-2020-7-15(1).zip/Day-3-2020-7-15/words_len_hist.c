
#include <stdio.h>
#include <string.h>
int main()
{
    int i,j;
    int number[11] ={1,2,3,4,5,6,7,8,9,10,-1};
    int twoDArray1[2][3]={{1,9,-13},{20,5,-6}};
    int twoDArray2[2][3]={{4,3,13},{2,51,-60}};
    int twoDArray3[2][3];
    for( i = 0; i<2; i++)
    {
        for(j = 0; j<3; j++)
        {
            twoDArray3[i][j]=twoDArray1[i][j]+twoDArray2[i][j];
        }

    }
    printf("result of addition\n");
    for( i = 0; i<2; i++)
    {
        for(j = 0; j<3; j++)
        {
            printf("%d,",twoDArray3[i][j]);
        }
        printf("\n");

    }
    return 0;
}
