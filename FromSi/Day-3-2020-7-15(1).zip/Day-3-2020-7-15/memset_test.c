

#include <stdio.h>
#include <string.h>
int main()
{
    int i,j;
    char myString[50] ={"hello World"};
    printf("myString is %s\n",myString);
    memset(myString,'\0',49);
    strcpy(myString,"new word");
    printf("myString is %s\n",myString);
    return 0;
}
